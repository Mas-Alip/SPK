# ui/perhitungan_ui.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import numpy as np
import csv
from models import database

RI_TABLE = {1:0.0,2:0.0,3:0.58,4:0.90,5:1.12,6:1.24,7:1.32,8:1.41,9:1.45,10:1.49}

class PerhitunganFrame(tk.Frame):
    """
    PerhitunganFrame:
    - Menampilkan bobot kriteria (AHP) yang diambil langsung dari tabel kriteria.
    - Menjalankan SAW memakai bobot tersebut.
    - Menampilkan hasil SAW dalam window baru (tabel) dan bisa export CSV.
    """

    def __init__(self, parent):
        super().__init__(parent)
        self._saw_result = None
        self.build_ui()
        self.load_bobot_from_db()

    # ---------------- UI ----------------
    def build_ui(self):
        header = ttk.Label(self, text="Perhitungan AHP & SAW", font=("Helvetica", 16, "bold"))
        header.pack(pady=10)

        # Frame AHP (read-only - bobot dari DB)
        frm_ahp = ttk.LabelFrame(self, text="AHP (Bobot kriteria dari DB)")
        frm_ahp.pack(fill="x", padx=12, pady=8)

        self.txt_bobot = tk.Text(frm_ahp, height=5, width=80)
        self.txt_bobot.pack(padx=8, pady=6)

        btn_frame_ahp = tk.Frame(frm_ahp)
        btn_frame_ahp.pack(fill="x", padx=8, pady=6)
        ttk.Button(btn_frame_ahp, text="Refresh Bobot", command=self.load_bobot_from_db).pack(side="left", padx=6)
        ttk.Button(btn_frame_ahp, text="Tampilkan CR (AHP)", command=self.show_cr).pack(side="left", padx=6)

        # Frame SAW
        frm_saw = ttk.LabelFrame(self, text="SAW (Hitung ranking nasabah)")
        frm_saw.pack(fill="both", expand=True, padx=12, pady=8)

        lbl = ttk.Label(frm_saw, text="Klik 'Hitung SAW' untuk menjalankan metode Simple Additive Weighting menggunakan bobot kriteria saat ini.")
        lbl.pack(anchor="w", padx=8, pady=(6,0))

        btns = tk.Frame(frm_saw)
        btns.pack(anchor="w", padx=8, pady=8)
        ttk.Button(btns, text="Hitung SAW", command=self.hitung_saw).pack(side="left", padx=6)
        ttk.Button(btns, text="Tampilkan Hasil (jika tersedia)", command=self.show_results_window).pack(side="left", padx=6)

        self.txt_saw = tk.Text(frm_saw, height=6)
        self.txt_saw.pack(fill="both", padx=8, pady=6, expand=False)

    # ---------------- Helpers: AHP bobot ----------------
    def load_bobot_from_db(self):
        """
        Ambil kriteria dari tabel kriteria (ORDER BY id).
        Tampilkan nama + bobot di text area.
        Simpan internally untuk perhitungan SAW.
        """
        try:
            conn = database.get_connection()
            cur = conn.cursor()
            cur.execute("SELECT id, nama, bobot FROM kriteria ORDER BY id")
            rows = cur.fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror("DB Error", f"Gagal membaca kriteria: {e}")
            return

        if not rows:
            self.criteria = []
            self.weights = np.array([])
            self.txt_bobot.delete("1.0", tk.END)
            self.txt_bobot.insert(tk.END, "Belum ada kriteria di database.")
            return

        # rows may be sqlite Row or tuples
        criteria = []
        weights = []
        for r in rows:
            # r could be (id,nama,bobot) or sqlite.Row
            nama = r[1]
            bobot = r[2]
            try:
                bw = float(bobot)
            except:
                bw = 0.0
            criteria.append(str(nama))
            weights.append(bw)

        weights = np.array(weights, dtype=float)
        # normalisasi bobot agar jumlah = 1 (jika belum)
        if not np.isclose(weights.sum(), 1.0):
            if weights.sum() == 0:
                # avoid division by zero: fallback equal weights
                weights = np.ones_like(weights) / len(weights)
            else:
                weights = weights / weights.sum()

        self.criteria = criteria
        self.weights = weights

        # show in text area
        self.txt_bobot.delete("1.0", tk.END)
        for name, w in zip(self.criteria, self.weights):
            self.txt_bobot.insert(tk.END, f"{name}: {w:.6f}\n")

    def show_cr(self):
        """
        Hitung CR (consistency ratio) dari bobot yang ada dengan merekonstruksi matriks pairwise
        a_ij = w_i / w_j (metode rekonstruksi). CR akan menjadi 0 jika w konsisten.
        Ini hanya memberikan info tambahan.
        """
        if not hasattr(self, "weights") or len(self.weights) == 0:
            messagebox.showinfo("Info", "Tidak ada bobot kriteria untuk dihitung.")
            return

        w = self.weights
        n = w.size
        # reconstruct pairwise
        pair = np.zeros((n,n), dtype=float)
        for i in range(n):
            for j in range(n):
                pair[i,j] = w[i] / w[j] if w[j] != 0 else 0.0

        # eigen
        eigvals = np.linalg.eigvals(pair)
        lambda_max = float(np.max(eigvals.real))
        CI = (lambda_max - n) / (n - 1) if n > 1 else 0.0
        RI = RI_TABLE.get(n, 1.49)
        CR = CI / RI if RI != 0 else 0.0

        messagebox.showinfo("CR (info)", f"λ_max = {lambda_max:.6f}\nCI = {CI:.6f}\nCR = {CR:.6f}")

    # ---------------- SAW computation ----------------
    def _map_criteria_to_columns(self, criteria_list):
        """
        Map nama kriteria (string) ke column name di tabel nasabah.
        Returns list of column names (strings), in same order as criteria_list.
        If a mapping cannot be found for some criteria, raise ValueError.
        Known mappings:
          - contains 'usia' -> 'usia'
          - contains 'pendapatan' or 'gaji' -> 'pendapatan'
          - contains 'pekerjaan' or 'job' -> 'pekerjaan'
          - contains 'jaminan' or 'agunan' -> 'jaminan'
        Otherwise try exact match to nasabah table columns.
        """
        # get existing columns from nasabah table
        conn = database.get_connection()
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(nasabah)")
        cols_info = cur.fetchall()
        conn.close()
        existing_cols = [c[1] for c in cols_info]  # name is at index 1

        mapped = []
        for crit in criteria_list:
            cn = crit.lower()
            if "usia" in cn:
                col = "usia"
            elif "pendapatan" in cn or "gaji" in cn or "income" in cn:
                col = "pendapatan"
            elif "pekerjaan" in cn or "job" in cn:
                col = "pekerjaan"
            elif "jaminan" in cn or "agunan" in cn or "collateral" in cn:
                col = "jaminan"
            else:
                # try exact match or safer variant
                cand = crit.strip().lower()
                if cand in existing_cols:
                    col = cand
                elif crit in existing_cols:
                    col = crit
                else:
                    # not found
                    raise ValueError(f"Kriteria '{crit}' tidak dapat dimapping ke kolom tabel nasabah.")
            if col not in existing_cols:
                raise ValueError(f"Kolom '{col}' (mapping dari kriteria '{crit}') tidak ditemukan di tabel nasabah.")
            mapped.append(col)
        return mapped

    def hitung_saw(self):
        """
        Core SAW computation:
         - ambil kriteria & bobot dari DB (done earlier)
         - map kriteria -> kolom nasabah
         - ambil data nasabah (id,nama,columns...)
         - normalisasi (benefit/cost)
         - skor = norm.dot(weights)
         - simpan hasil ke self._saw_result dan tampilkan ringkasan di text area
        """
        try:
            if not hasattr(self, "criteria") or len(self.criteria) == 0:
                messagebox.showerror("Error", "Tidak ada kriteria di database. Tambahkan kriteria terlebih dahulu.")
                return

            # map criteria names to nasabah columns
            cols = self._map_criteria_to_columns(self.criteria)  # may raise ValueError

            # load nasabah data (id, nama, col1, col2, ...)
            conn = database.get_connection()
            cur = conn.cursor()
            select_cols = ", ".join([f'"{c}"' for c in cols])
            sql = f"SELECT id, nama, {select_cols} FROM nasabah"
            cur.execute(sql)
            rows = cur.fetchall()
            conn.close()

            if not rows:
                messagebox.showinfo("Info", "Data nasabah kosong.")
                return

            # build matrix and names
            names = []
            ids = []
            matrix = []
            for r in rows:
                ids.append(r[0])
                names.append(r[1])
                vals = []
                for i, c in enumerate(cols):
                    raw = r[2 + i]
                    try:
                        vals.append(float(raw))
                    except:
                        raise ValueError(f"Nilai untuk kolom '{c}' pada nasabah '{r[1]}' bukan angka: {raw}")
                matrix.append(vals)
            matrix = np.array(matrix, dtype=float)  # shape (n_alt, n_crit)

            # prepare weights (align with criteria order)
            weights = self.weights.copy()
            if weights.size != matrix.shape[1]:
                # mismatch: provide clear message
                raise ValueError(f"Jumlah bobot ({weights.size}) tidak cocok dengan jumlah kriteria yang dipetakan ({matrix.shape[1]}). Periksa tabel kriteria.")
            # ensure normalized
            if not np.isclose(weights.sum(), 1.0):
                weights = weights / weights.sum()

            # decide benefit flags: usia -> cost, others -> benefit
            benefit_flags = []
            for c in cols:
                if "usia" in c.lower():
                    benefit_flags.append(False)
                else:
                    benefit_flags.append(True)

            # normalization SAW
            n_alt, n_crit = matrix.shape
            norm = np.zeros_like(matrix, dtype=float)

            for j in range(n_crit):
                col = matrix[:, j]
                if benefit_flags[j]:
                    maxv = np.max(col)
                    if maxv == 0:
                        norm[:, j] = 0.0
                    else:
                        norm[:, j] = col / maxv
                else:
                    # cost
                    minv = np.min(col)
                    # avoid division by zero
                    safe_col = np.where(col == 0, 1e-9, col)
                    norm[:, j] = minv / safe_col

            # compute scores
            scores = norm.dot(weights)

            # prepare result rows sorted by score desc
            results = []
            for idx in range(n_alt):
                results.append({
                    "id": ids[idx],
                    "nama": names[idx],
                    "score": float(scores[idx]),
                    "raw_values": matrix[idx,:].tolist(),
                    "r_values": norm[idx,:].tolist()
                })
            # sort
            results_sorted = sorted(results, key=lambda x: x["score"], reverse=True)
            # assign rank
            for i, row in enumerate(results_sorted, start=1):
                row["rank"] = i

            # store result for later display/export
            self._saw_result = {
                "criteria": self.criteria,
                "columns": cols,
                "weights": weights.tolist(),
                "results": results_sorted
            }

            # show brief output
            out_lines = []
            out_lines.append("SAW selesai. Contoh 10 teratas:")
            for item in results_sorted[:10]:
                out_lines.append(f"#{item['rank']}  {item['nama']}  -> {item['score']:.6f}")
            self.txt_saw.delete("1.0", tk.END)
            self.txt_saw.insert(tk.END, "\n".join(out_lines))
            messagebox.showinfo("Sukses", "Perhitungan SAW selesai. Klik 'Tampilkan Hasil' untuk tabel lengkap.")
        except Exception as e:
            messagebox.showerror("Error SAW", f"Gagal menghitung SAW:\n{e}")

    # ---------------- Results Window ----------------
    def show_results_window(self):
        if not self._saw_result:
            messagebox.showinfo("Info", "Belum ada hasil SAW. Klik 'Hitung SAW' terlebih dahulu.")
            return

        data = self._saw_result
        criteria = data["criteria"]
        cols = data["columns"]
        results = data["results"]

        win = tk.Toplevel(self)
        win.title("Hasil SAW - Ranking Nasabah")
        win.geometry("900x500")

        # top buttons
        top = tk.Frame(win)
        top.pack(fill="x", pady=6, padx=6)
        ttk.Button(top, text="Export CSV", command=lambda: self._export_csv(results, criteria, cols)).pack(side="left", padx=6)
        ttk.Button(top, text="Tutup", command=win.destroy).pack(side="right", padx=6)

        # treeview columns: Rank, ID, Nama, Score, then each criteria
        tree_cols = ["Rank", "ID", "Nama", "Score"] + criteria
        tree = ttk.Treeview(win, columns=tree_cols, show="headings")
        for c in tree_cols:
            tree.heading(c, text=c)
            # set width
            if c == "Nama":
                tree.column(c, width=220)
            elif c == "Score":
                tree.column(c, width=100, anchor="center")
            elif c == "Rank":
                tree.column(c, width=60, anchor="center")
            else:
                tree.column(c, width=120)
        tree.pack(fill="both", expand=True, padx=6, pady=6)

        # insert rows
        for item in results:
            row_vals = [item["rank"], item["id"], item["nama"], round(item["score"], 6)]
            # add readable labels for each criterion if mapping known
            for j, raw in enumerate(item["raw_values"]):
                colname = cols[j]
                # map some known columns to friendly labels
                if colname == "usia":
                    v = {1:"<25",2:"25-35",3:"36-50",4:">50"}.get(int(raw), str(raw))
                elif colname == "pendapatan":
                    v = {1:"<2jt",2:"2-5jt",3:"5-10jt",4:">10jt"}.get(int(raw), str(raw))
                elif colname == "pekerjaan":
                    v = {1:"PNS/Tetap",2:"Wiraswasta",3:"Buruh/Kontrak",4:"Lainnya"}.get(int(raw), str(raw))
                elif colname == "jaminan":
                    v = {1:"Sertifikat",2:"BPKB",3:"Tanpa Jaminan"}.get(int(raw), str(raw))
                else:
                    v = str(raw)
                row_vals.append(v)
            tree.insert("", "end", values=row_vals)

    def _export_csv(self, results, criteria, cols):
        if not results:
            messagebox.showinfo("Info", "Tidak ada data untuk diexport.")
            return
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")])
        if not file_path:
            return
        header = ["Rank","ID","Nama","Score"] + criteria
        try:
            with open(file_path, "w", newline='', encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(header)
                for item in results:
                    row = [item["rank"], item["id"], item["nama"], f"{item['score']:.6f}"]
                    # write raw values (or mapped labels)
                    for j, raw in enumerate(item["raw_values"]):
                        colname = cols[j]
                        if colname == "usia":
                            v = {1:"<25",2:"25-35",3:"36-50",4:">50"}.get(int(raw), raw)
                        elif colname == "pendapatan":
                            v = {1:"<2jt",2:"2-5jt",3:"5-10jt",4:">10jt"}.get(int(raw), raw)
                        elif colname == "pekerjaan":
                            v = {1:"PNS/Tetap",2:"Wiraswasta",3:"Buruh/Kontrak",4:"Lainnya"}.get(int(raw), raw)
                        elif colname == "jaminan":
                            v = {1:"Sertifikat",2:"BPKB",3:"Tanpa Jaminan"}.get(int(raw), raw)
                        else:
                            v = raw
                        row.append(v)
                    writer.writerow(row)
            messagebox.showinfo("Sukses", f"Hasil berhasil diexport ke {file_path}")
        except Exception as e:
            messagebox.showerror("Error export", f"Gagal menyimpan CSV: {e}")
