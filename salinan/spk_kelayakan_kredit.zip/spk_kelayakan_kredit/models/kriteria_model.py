from .database import get_connection

def tambah_kriteria(nama, bobot):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO kriteria (nama, bobot) VALUES (?, ?)", (nama, bobot))
    conn.commit()
    conn.close()

def get_all_kriteria():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM kriteria")
    data = cur.fetchall()
    conn.close()
    return data
